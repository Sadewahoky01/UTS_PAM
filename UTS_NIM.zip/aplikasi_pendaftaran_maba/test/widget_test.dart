import 'package:flutter_test/flutter_test.dart';
import 'package:aplikasi_pendaftaran_maba/main.dart';

void main() {
  testWidgets('Menampilkan halaman utama Aplikasi Pendaftaran Mahasiswa Baru',
      (WidgetTester tester) async {
    await tester.pumpWidget(const AplikasiPendaftaranMabaApp());

    expect(find.text('Pendaftaran Mahasiswa Baru'), findsWidgets);
    expect(find.text('Mulai Pendaftaran'), findsOneWidget);
    expect(find.text('Tentang Aplikasi'), findsOneWidget);
  });
}
