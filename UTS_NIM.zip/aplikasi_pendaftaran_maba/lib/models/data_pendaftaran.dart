// ============================================================================
// FILE PENDUKUNG: lib/models/data_pendaftaran.dart
// Menyimpan model data pendaftaran mahasiswa baru beserta konstanta identitas.
// ============================================================================

const String kNamaAplikasi = 'Pendaftaran Mahasiswa Baru';
const String kNamaMahasiswa = 'Ananda Pratama';
const String kNimMahasiswa = '2411010001'; // Ganti dengan NIM Anda
const String kProgramStudi = 'Informatika (IF)';
const String kNamaUniversitas = 'Universitas Potensi Utama';

class DataPendaftaran {
  final String namaLengkap;
  final String nomorPendaftaran;
  final String alamat;
  final String programStudi;
  final String jenisKelamin;
  final DateTime tanggalLahir;

  const DataPendaftaran({
    required this.namaLengkap,
    required this.nomorPendaftaran,
    required this.alamat,
    required this.programStudi,
    required this.jenisKelamin,
    required this.tanggalLahir,
  });

  String get tanggalLahirFormatted {
    const List<String> namaBulan = [
      'Januari',
      'Februari',
      'Maret',
      'April',
      'Mei',
      'Juni',
      'Juli',
      'Agustus',
      'September',
      'Oktober',
      'November',
      'Desember',
    ];
    return '${tanggalLahir.day.toString().padLeft(2, '0')} '
        '${namaBulan[tanggalLahir.month - 1]} '
        '${tanggalLahir.year}';
  }
}
