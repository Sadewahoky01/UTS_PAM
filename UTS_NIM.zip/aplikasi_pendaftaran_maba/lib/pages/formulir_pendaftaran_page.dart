import 'package:flutter/material.dart';
import '../models/data_pendaftaran.dart';
import '../widgets/kampus_logo_widget.dart';
import 'hasil_pendaftaran_page.dart';

// ============================================================================
// FILE PENDUKUNG: lib/pages/formulir_pendaftaran_page.dart
// Halaman Formulir Pendaftaran dengan 9 komponen sesuai ketentuan soal UTS.
// ============================================================================
class FormulirPendaftaranPage extends StatefulWidget {
  const FormulirPendaftaranPage({super.key});

  @override
  State<FormulirPendaftaranPage> createState() =>
      _FormulirPendaftaranPageState();
}

class _FormulirPendaftaranPageState extends State<FormulirPendaftaranPage> {
  final TextEditingController _namaController = TextEditingController();
  final TextEditingController _nomorPendaftaranController =
      TextEditingController();
  final TextEditingController _alamatController = TextEditingController();

  final List<String> _daftarProdi = const [
    'Informatika (S1)',
    'Sistem Informasi (S1)',
    'Rekayasa Perangkat Lunak (S1)',
    'Teknik Industri (S1)',
    'Desain Komunikasi Visual (S1)',
  ];

  String? _selectedProdi;
  String? _selectedJenisKelamin;
  DateTime? _selectedTanggalLahir;

  @override
  void dispose() {
    _namaController.dispose();
    _nomorPendaftaranController.dispose();
    _alamatController.dispose();
    super.dispose();
  }

  Future<void> _pilihTanggalLahir() async {
    final DateTime sekarang = DateTime.now();
    final DateTime? hasil = await showDatePicker(
      context: context,
      initialDate: _selectedTanggalLahir ?? DateTime(2005, 5, 14),
      firstDate: DateTime(1980),
      lastDate: sekarang,
      helpText: 'PILIH TANGGAL LAHIR CALON MAHASISWA',
      cancelText: 'BATAL',
      confirmText: 'PILIH',
    );

    if (hasil != null) {
      setState(() {
        _selectedTanggalLahir = hasil;
      });
    }
  }

  String _formatTanggal(DateTime date) {
    const List<String> namaBulan = [
      'Januari',
      'Februari',
      'Maret',
      'April',
      'Mei',
      'Juni',
      'Juli',
      'Agustus',
      'September',
      'Oktober',
      'November',
      'Desember',
    ];
    return '${date.day.toString().padLeft(2, '0')} '
        '${namaBulan[date.month - 1]} '
        '${date.year}';
  }

  void _simpanPendaftaran() {
    final String nama = _namaController.text.trim();
    final String nomorPendaftaran = _nomorPendaftaranController.text.trim();
    final String alamat = _alamatController.text.trim();

    final List<String> dataBelumLengkap = [];
    if (nama.isEmpty) dataBelumLengkap.add('Nama Lengkap');
    if (nomorPendaftaran.isEmpty) {
      dataBelumLengkap.add('NIM / Nomor Pendaftaran');
    }
    if (alamat.isEmpty) dataBelumLengkap.add('Alamat');
    if (_selectedProdi == null) dataBelumLengkap.add('Program Studi');
    if (_selectedJenisKelamin == null) dataBelumLengkap.add('Jenis Kelamin');
    if (_selectedTanggalLahir == null) dataBelumLengkap.add('Tanggal Lahir');

    if (dataBelumLengkap.isNotEmpty) {
      ScaffoldMessenger.of(context).hideCurrentSnackBar();
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          backgroundColor: const Color(0xFFDC2626),
          behavior: SnackBarBehavior.floating,
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(10),
          ),
          content: Row(
            children: [
              const Icon(Icons.warning_amber_rounded, color: Colors.white),
              const SizedBox(width: 10),
              Expanded(
                child: Text(
                  'Mohon lengkapi seluruh data wajib: ${dataBelumLengkap.join(', ')}!',
                  style: const TextStyle(fontWeight: FontWeight.w600),
                ),
              ),
            ],
          ),
        ),
      );
      return;
    }

    final dataPendaftaran = DataPendaftaran(
      namaLengkap: nama,
      nomorPendaftaran: nomorPendaftaran,
      alamat: alamat,
      programStudi: _selectedProdi!,
      jenisKelamin: _selectedJenisKelamin!,
      tanggalLahir: _selectedTanggalLahir!,
    );

    Navigator.push(
      context,
      MaterialPageRoute(
        builder: (context) =>
            HasilPendaftaranPage(dataPendaftaran: dataPendaftaran),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text(
          'Formulir Pendaftaran',
          style: TextStyle(fontWeight: FontWeight.bold, fontSize: 18),
        ),
      ),
      body: SafeArea(
        child: SingleChildScrollView(
          padding: const EdgeInsets.all(18.0),
          child: Center(
            child: ConstrainedBox(
              constraints: const BoxConstraints(maxWidth: 480),
              child: Card(
                elevation: 2,
                color: Colors.white,
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(18),
                ),
                child: Padding(
                  padding: const EdgeInsets.all(20.0),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.stretch,
                    children: [
                      // [8] ImageView: Menampilkan logo atau gambar
                      const Center(child: KampusLogoWidget(size: 74)),
                      const SizedBox(height: 12),

                      // [1] TextView / Text: Menampilkan judul formulir
                      const Text(
                        'Formulir Pendaftaran Mahasiswa Baru',
                        textAlign: TextAlign.center,
                        style: TextStyle(
                          fontSize: 18,
                          fontWeight: FontWeight.w800,
                          color: Color(0xFF1E3A8A),
                        ),
                      ),
                      const SizedBox(height: 4),
                      const Text(
                        'Lengkapi seluruh data calon mahasiswa di bawah ini.',
                        textAlign: TextAlign.center,
                        style: TextStyle(
                          fontSize: 12.5,
                          color: Color(0xFF64748B),
                        ),
                      ),
                      const SizedBox(height: 16),
                      const Divider(),
                      const SizedBox(height: 12),

                      // [2] EditText / TextField: Mengisi nama lengkap
                      const Text(
                        'Nama Lengkap *',
                        style: TextStyle(
                          fontSize: 13,
                          fontWeight: FontWeight.w700,
                          color: Color(0xFF1E293B),
                        ),
                      ),
                      const SizedBox(height: 6),
                      TextField(
                        controller: _namaController,
                        textInputAction: TextInputAction.next,
                        decoration: const InputDecoration(
                          hintText: 'Masukkan nama lengkap sesuai ijazah',
                          prefixIcon: Icon(Icons.person_outline_rounded),
                        ),
                      ),
                      const SizedBox(height: 14),

                      // [3] EditText / TextField: Mengisi NIM atau nomor pendaftaran
                      const Text(
                        'NIM / Nomor Pendaftaran *',
                        style: TextStyle(
                          fontSize: 13,
                          fontWeight: FontWeight.w700,
                          color: Color(0xFF1E293B),
                        ),
                      ),
                      const SizedBox(height: 6),
                      TextField(
                        controller: _nomorPendaftaranController,
                        textInputAction: TextInputAction.next,
                        decoration: const InputDecoration(
                          hintText: 'Contoh: PMB-2026-001 atau NIM',
                          prefixIcon: Icon(Icons.badge_outlined),
                        ),
                      ),
                      const SizedBox(height: 14),

                      // [4] EditText / TextField: Mengisi alamat
                      const Text(
                        'Alamat Lengkap *',
                        style: TextStyle(
                          fontSize: 13,
                          fontWeight: FontWeight.w700,
                          color: Color(0xFF1E293B),
                        ),
                      ),
                      const SizedBox(height: 6),
                      TextField(
                        controller: _alamatController,
                        textInputAction: TextInputAction.done,
                        decoration: const InputDecoration(
                          hintText: 'Masukkan alamat tempat tinggal lengkap',
                          prefixIcon: Icon(Icons.home_outlined),
                        ),
                      ),
                      const SizedBox(height: 14),

                      // [5] Spinner / Dropdown: Memilih program studi
                      const Text(
                        'Program Studi Pilihan *',
                        style: TextStyle(
                          fontSize: 13,
                          fontWeight: FontWeight.w700,
                          color: Color(0xFF1E293B),
                        ),
                      ),
                      const SizedBox(height: 6),
                      DropdownButtonFormField<String>(
                        value: _selectedProdi,
                        decoration: const InputDecoration(
                          hintText: 'Pilih Program Studi',
                          prefixIcon: Icon(Icons.school_outlined),
                        ),
                        items: _daftarProdi.map((String prodi) {
                          return DropdownMenuItem<String>(
                            value: prodi,
                            child: Text(prodi),
                          );
                        }).toList(),
                        onChanged: (String? newValue) {
                          setState(() {
                            _selectedProdi = newValue;
                          });
                        },
                      ),
                      const SizedBox(height: 14),

                      // [6] Radio Button: Memilih jenis kelamin
                      const Text(
                        'Jenis Kelamin *',
                        style: TextStyle(
                          fontSize: 13,
                          fontWeight: FontWeight.w700,
                          color: Color(0xFF1E293B),
                        ),
                      ),
                      const SizedBox(height: 6),
                      Container(
                        decoration: BoxDecoration(
                          color: Colors.white,
                          borderRadius: BorderRadius.circular(12),
                          border: Border.all(color: const Color(0xFFCBD5E1)),
                        ),
                        child: Row(
                          children: [
                            Expanded(
                              child: RadioListTile<String>(
                                title: const Text(
                                  'Laki-laki',
                                  style: TextStyle(fontSize: 13.5),
                                ),
                                value: 'Laki-laki',
                                groupValue: _selectedJenisKelamin,
                                onChanged: (String? value) {
                                  setState(() {
                                    _selectedJenisKelamin = value;
                                  });
                                },
                                contentPadding: const EdgeInsets.symmetric(
                                  horizontal: 6,
                                ),
                                dense: true,
                              ),
                            ),
                            Expanded(
                              child: RadioListTile<String>(
                                title: const Text(
                                  'Perempuan',
                                  style: TextStyle(fontSize: 13.5),
                                ),
                                value: 'Perempuan',
                                groupValue: _selectedJenisKelamin,
                                onChanged: (String? value) {
                                  setState(() {
                                    _selectedJenisKelamin = value;
                                  });
                                },
                                contentPadding: const EdgeInsets.symmetric(
                                  horizontal: 6,
                                ),
                                dense: true,
                              ),
                            ),
                          ],
                        ),
                      ),
                      const SizedBox(height: 14),

                      // [7] DatePicker: Memilih tanggal lahir
                      const Text(
                        'Tanggal Lahir *',
                        style: TextStyle(
                          fontSize: 13,
                          fontWeight: FontWeight.w700,
                          color: Color(0xFF1E293B),
                        ),
                      ),
                      const SizedBox(height: 6),
                      InkWell(
                        onTap: _pilihTanggalLahir,
                        borderRadius: BorderRadius.circular(12),
                        child: InputDecorator(
                          decoration: const InputDecoration(
                            prefixIcon: Icon(Icons.calendar_month_outlined),
                            suffixIcon: Icon(Icons.arrow_drop_down),
                          ),
                          child: Text(
                            _selectedTanggalLahir == null
                                ? 'Pilih Tanggal Lahir'
                                : _formatTanggal(_selectedTanggalLahir!),
                            style: TextStyle(
                              fontSize: 14,
                              color: _selectedTanggalLahir == null
                                  ? const Color(0xFF64748B)
                                  : const Color(0xFF1E293B),
                            ),
                          ),
                        ),
                      ),
                      const SizedBox(height: 22),

                      // [9] Button: Menyimpan data pendaftaran
                      SizedBox(
                        height: 48,
                        child: ElevatedButton.icon(
                          onPressed: _simpanPendaftaran,
                          icon: const Icon(Icons.save_rounded),
                          label: const Text(
                            'Simpan Pendaftaran',
                            style: TextStyle(
                              fontSize: 15.5,
                              fontWeight: FontWeight.bold,
                            ),
                          ),
                          style: ElevatedButton.styleFrom(
                            backgroundColor: const Color(0xFF1E3A8A),
                            foregroundColor: Colors.white,
                            shape: RoundedRectangleBorder(
                              borderRadius: BorderRadius.circular(12),
                            ),
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
              ),
            ),
          ),
        ),
      ),
    );
  }
}
