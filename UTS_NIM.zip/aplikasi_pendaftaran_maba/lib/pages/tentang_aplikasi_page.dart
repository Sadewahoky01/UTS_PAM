import 'package:flutter/material.dart';
import '../models/data_pendaftaran.dart';
import '../widgets/kampus_logo_widget.dart';

// ============================================================================
// FILE PENDUKUNG: lib/pages/tentang_aplikasi_page.dart
// Halaman Tentang Aplikasi yang menampilkan:
// - Nama aplikasi
// - Nama mahasiswa pembuat aplikasi
// - NIM
// - Program Studi Informatika
// - Nama universitas
// ============================================================================
class TentangAplikasiPage extends StatelessWidget {
  const TentangAplikasiPage({super.key});

  Widget _buildInfoRow({
    required IconData icon,
    required String title,
    required String subtitle,
  }) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 10.0),
      child: Row(
        children: [
          Container(
            padding: const EdgeInsets.all(10),
            decoration: BoxDecoration(
              color: const Color(0xFFEFF6FF),
              borderRadius: BorderRadius.circular(10),
            ),
            child: Icon(icon, color: const Color(0xFF1E3A8A), size: 22),
          ),
          const SizedBox(width: 14),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  title,
                  style: const TextStyle(
                    fontSize: 12,
                    color: Color(0xFF64748B),
                    fontWeight: FontWeight.w500,
                  ),
                ),
                const SizedBox(height: 2),
                Text(
                  subtitle,
                  style: const TextStyle(
                    fontSize: 15,
                    color: Color(0xFF0F172A),
                    fontWeight: FontWeight.w700,
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text(
          'Tentang Aplikasi',
          style: TextStyle(fontWeight: FontWeight.bold, fontSize: 18),
        ),
      ),
      body: SafeArea(
        child: SingleChildScrollView(
          padding: const EdgeInsets.all(24.0),
          child: Center(
            child: ConstrainedBox(
              constraints: const BoxConstraints(maxWidth: 480),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.stretch,
                children: [
                  Card(
                    elevation: 3,
                    color: Colors.white,
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(20),
                    ),
                    child: Padding(
                      padding: const EdgeInsets.all(24.0),
                      child: Column(
                        children: [
                          const KampusLogoWidget(size: 100),
                          const SizedBox(height: 16),
                          const Text(
                            kNamaAplikasi,
                            textAlign: TextAlign.center,
                            style: TextStyle(
                              fontSize: 20,
                              fontWeight: FontWeight.w800,
                              color: Color(0xFF1E3A8A),
                            ),
                          ),
                          const SizedBox(height: 4),
                          const Text(
                            'Versi 1.0.0 — UTS Pengembangan Aplikasi Mobile',
                            textAlign: TextAlign.center,
                            style: TextStyle(
                              fontSize: 12,
                              color: Color(0xFF64748B),
                            ),
                          ),
                          const SizedBox(height: 20),
                          const Divider(),
                          _buildInfoRow(
                            icon: Icons.apps_rounded,
                            title: 'Nama Aplikasi',
                            subtitle: kNamaAplikasi,
                          ),
                          const Divider(height: 1),
                          _buildInfoRow(
                            icon: Icons.person_rounded,
                            title: 'Nama Mahasiswa Pembuat Aplikasi',
                            subtitle: kNamaMahasiswa,
                          ),
                          const Divider(height: 1),
                          _buildInfoRow(
                            icon: Icons.badge_rounded,
                            title: 'Nomor Induk Mahasiswa (NIM)',
                            subtitle: kNimMahasiswa,
                          ),
                          const Divider(height: 1),
                          _buildInfoRow(
                            icon: Icons.computer_rounded,
                            title: 'Program Studi',
                            subtitle: kProgramStudi,
                          ),
                          const Divider(height: 1),
                          _buildInfoRow(
                            icon: Icons.account_balance_rounded,
                            title: 'Nama Universitas',
                            subtitle: kNamaUniversitas,
                          ),
                        ],
                      ),
                    ),
                  ),
                  const SizedBox(height: 20),
                  SizedBox(
                    height: 50,
                    child: OutlinedButton.icon(
                      onPressed: () => Navigator.pop(context),
                      icon: const Icon(Icons.arrow_back_rounded),
                      label: const Text(
                        'Kembali ke Halaman Utama',
                        style: TextStyle(
                          fontSize: 15,
                          fontWeight: FontWeight.bold,
                        ),
                      ),
                      style: OutlinedButton.styleFrom(
                        foregroundColor: const Color(0xFF1E3A8A),
                        side: const BorderSide(
                          color: Color(0xFF1E3A8A),
                          width: 1.8,
                        ),
                        backgroundColor: Colors.white,
                        shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(12),
                        ),
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }
}
