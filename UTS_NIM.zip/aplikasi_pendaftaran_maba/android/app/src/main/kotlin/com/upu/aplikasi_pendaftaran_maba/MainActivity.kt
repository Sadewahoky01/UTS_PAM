package com.upu.aplikasi_pendaftaran_maba

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
